from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib import colors
from reportlab.lib.units import mm
from assessment.db import get_attempt
from assessment.scoring import profile,clusters
def make_report(aid):
    a=get_attempt(aid);p=profile(aid);c=clusters(p);b=BytesIO();d=SimpleDocTemplate(b,pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=18*mm);s=getSampleStyleSheet();story=[Paragraph('CAREER DISCOVERY REPORT',s['Title']),Spacer(1,8),Paragraph(f"<b>Student:</b> {a['name']}<br/><b>Code:</b> {a['student_code']}<br/><b>School:</b> {a.get('school') or '—'}<br/><b>Class:</b> {a.get('class_level') or '—'}",s['BodyText']),Paragraph('1. Executive Summary',s['Heading2'])]
    top=list(c.items())[:3];story.append(Paragraph(f"Strongest current exploration areas: {', '.join(f'{x} ({y}%)' for x,y in top)}. This is an exploration profile, not a prediction or fixed career decision.",s['BodyText']))
    story.append(Paragraph('2. Career Cluster Profile',s['Heading2']));t=Table([['Career cluster','Alignment']]+[[x,f'{y}%'] for x,y in c.items()],colWidths=[125*mm,35*mm]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8EEF7')),('GRID',(0,0),(-1,-1),.4,colors.grey),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('ALIGN',(1,1),(1,-1),'CENTER')]));story.append(t)
    story.append(Paragraph('3. Assessment Dimensions',s['Heading2']));t=Table([['Dimension','Score','Level']]+[[x,f'{y}%',('Very strong' if y>=85 else 'Strong' if y>=70 else 'Moderate' if y>=50 else 'Emerging')] for x,y in sorted(p.items(),key=lambda x:x[1],reverse=True)],colWidths=[85*mm,30*mm,45*mm]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8EEF7')),('GRID',(0,0),(-1,-1),.4,colors.grey),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('ALIGN',(1,1),(1,-1),'CENTER')]));story.append(t)
    story += [PageBreak(),Paragraph('4. Exploration Plan',s['Heading2'])]
    for x in ['Explore the top three clusters before choosing a stream or course.','Try one practical activity in each leading cluster.','Speak with at least two professionals, teachers or counsellors.','Use academic performance and real experiences alongside this profile.']:story.append(Paragraph('• '+x,s['BodyText']))
    story += [Paragraph('5. Important Note',s['Heading2']),Paragraph('This MVP is an educational career-exploration aid. It is not a clinical assessment, diagnosis, admission guarantee or validated psychometric test. Commercial use should follow appropriate psychometric validation.',s['BodyText'])];d.build(story);return b.getvalue()
