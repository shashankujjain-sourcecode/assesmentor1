import os,json,uuid,random
from datetime import datetime,timezone
from sqlalchemy import create_engine,text
URL=os.getenv('DATABASE_URL','sqlite:///career_assessment.db')
engine=create_engine(URL,connect_args={'check_same_thread':False} if URL.startswith('sqlite') else {},pool_pre_ping=True)
def now(): return datetime.now(timezone.utc).isoformat()
def init_db():
    with engine.begin() as c:
        c.execute(text('CREATE TABLE IF NOT EXISTS attempts (id TEXT PRIMARY KEY,name TEXT NOT NULL,student_code TEXT NOT NULL,school TEXT,class_level TEXT,seed INTEGER NOT NULL,status TEXT NOT NULL,current_index INTEGER NOT NULL DEFAULT 0,answers TEXT NOT NULL DEFAULT \'{}\',used_question_ids TEXT NOT NULL DEFAULT \'[]\',created_at TEXT NOT NULL,completed_at TEXT)'))
def dec(r):
    d=dict(r); d['answers']=json.loads(d['answers']); d['used_question_ids']=json.loads(d['used_question_ids']); return d
def get_attempt(aid):
    with engine.connect() as c:
        r=c.execute(text('SELECT * FROM attempts WHERE id=:id'),{'id':aid}).mappings().first()
        if not r: raise ValueError('Attempt not found')
        return dec(r)
def start_attempt(name,code,school,cls):
    with engine.begin() as c:
        r=c.execute(text("SELECT * FROM attempts WHERE student_code=:code AND status='in_progress' ORDER BY created_at DESC LIMIT 1"),{'code':code}).mappings().first()
        if r:return dec(r)
        aid=str(uuid.uuid4())
        c.execute(text('INSERT INTO attempts (id,name,student_code,school,class_level,seed,status,current_index,answers,used_question_ids,created_at) VALUES (:id,:name,:code,:school,:cls,:seed,\'in_progress\',0,\'{}\',\'[]\',:t)'),{'id':aid,'name':name,'code':code,'school':school,'cls':cls,'seed':random.randint(1,2_000_000_000),'t':now()})
        return get_attempt(aid)
def save_answer(aid,qid,answer):
    a=get_attempt(aid); a['answers'][qid]=answer
    with engine.begin() as c:c.execute(text('UPDATE attempts SET answers=:x WHERE id=:id'),{'x':json.dumps(a['answers']),'id':aid})
def set_index(aid,i):
    with engine.begin() as c:c.execute(text('UPDATE attempts SET current_index=:i WHERE id=:id'),{'i':i,'id':aid})
def finish_attempt(aid):
    with engine.begin() as c:c.execute(text('UPDATE attempts SET status=\'completed\',completed_at=:t WHERE id=:id'),{'t':now(),'id':aid})
