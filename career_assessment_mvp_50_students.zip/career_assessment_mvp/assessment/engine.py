import json,random
from pathlib import Path
BANK=Path(__file__).parent/'questions.json'
class Assessment:
    def __init__(self,a):
        self.a=a
        with open(BANK,encoding='utf-8') as f: bank=json.load(f)
        random.seed(a['seed']); random.shuffle(bank)
        self.questions=bank[:min(8,len(bank))]
