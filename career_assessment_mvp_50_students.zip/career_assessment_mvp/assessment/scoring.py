import json
from pathlib import Path
from assessment.db import get_attempt
BANK=Path(__file__).parent/'questions.json'
def profile(aid):
    a=get_attempt(aid)
    with open(BANK,encoding='utf-8') as f: bank={q['id']:q for q in json.load(f)}
    s={};n={}
    for qid,ans in a['answers'].items():
        q=bank.get(qid)
        if not q or ans not in q['options']:continue
        for d,w in q['weights'][q['options'].index(ans)].items():s[d]=s.get(d,0)+w;n[d]=n.get(d,0)+1
    return {d:round(v/(n[d]*4)*100) for d,v in s.items() if n[d]}
def clusters(p):
    rules={'Technology & Engineering':['Technology','Engineering','Logical','Numerical'],'Data & Analytics':['Numerical','Logical','Analytical'],'Business & Management':['Business','Leadership','Achievement'],'Healthcare & Life Sciences':['Healthcare','Scientific','Social'],'Creative & Design':['Creative'],'Law & Public Policy':['Verbal','Leadership','Social','Achievement']}
    return dict(sorted({k:round(sum(p.get(x,0) for x in v)/len(v)) for k,v in rules.items()}.items(),key=lambda x:x[1],reverse=True))
